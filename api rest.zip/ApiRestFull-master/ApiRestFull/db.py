import sqlite3

def GetConnection():
    conn = sqlite3.connect('agenda.db')
    return conn

def CreateDbTable():
    success = True
    try:
        conn = GetConnection()
        conn.execute('''
            CREATE TABLE contacts (
                id INTEGER PRIMARY KEY NOT NULL,
                name TEXT,
                company TEXT,
                phone TEXT,
                email TEXT
            );
        ''')
        conn.commit()
        return success
    except:
        success = False
        return success
    finally:
        conn.close()

def InsertContact(contact):
    insertContact = {}
    try:
        conn = GetConnection()
        cur = conn.cursor()
        cur.execute("INSERT INTO contacts (name, company, phone, email) VALUES (?, ?, ?, ?)",
                    (contact["name"],
                    contact["company"],
                    contact["phone"],
                    contact["email"]) )
        conn.commit()
        insertContact = GetContactById(cur.lastrowid)
    except:
        conn().rollback()
    finally:
        conn.close()
    return insertContact        

def GetAllContacts():
    contacts = []
    try:
        conn = GetConnection()
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT * FROM contacts")
        rows = cur.fetchall()

        for row in rows:
            contact = {}
            contact["id"]      = row["id"]
            contact["name"]    = row["name"]
            contact["company"] = row["company"]
            contact["phone"]   = row["phone"]
            contact["email"]   = row["email"]            
            contacts.append(contact)
    except:
        contacts = []

    return contacts

def GetContactById(id):
    contact = {}
    try:
        conn = GetConnection()
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT * FROM contacts WHERE id = ?", 
                       (id))
        row = cur.fetchone()
  
        contact["id"]      = row["id"]
        contact["name"]    = row["name"]
        contact["company"] = row["company"]
        contact["phone"]   = row["phone"]
        contact["email"]   = row["email"]
    except:
        contact = {}
    return contact

def GetContactByName(name):
    contacts = []
    try:
        conn = GetConnection()
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        sql = f"SELECT * FROM contacts WHERE name LIKE '%{name}%'"
        cur.execute(sql)
        rows = cur.fetchall()
        for row in rows:
            contacts.append({
                "id": row["id"],
                "name": row["name"],
                "company": row["company"],
                "phone": row["phone"],
                "email": row["email"]
            }) 
    except:
        contacts = []
    return contacts  

def GetContactByCompany(company):
    contacts = []
    try:
        conn = GetConnection()
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        sql = f"SELECT * FROM contacts WHERE company LIKE '%{company}%'"
        cur.execute(sql)
        rows = cur.fetchall()
        for row in rows:
            contacts.append({
                "id": row["id"],
                "name": row["name"],
                "company": row["company"],
                "phone": row["phone"],
                "email": row["email"]
            }) 
    except:
        contacts = []
    return contacts       

def GetContactByEmail(email):
    contacts = []
    try:
        conn = GetConnection()
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        sql = f"SELECT * FROM contacts WHERE email LIKE '%{email}%'"
        cur.execute(sql)
        rows = cur.fetchall()
        for row in rows:
            contacts.append({
                "id": row["id"],
                "name": row["name"],
                "company": row["company"],
                "phone": row["phone"],
                "email": row["email"]
            }) 
    except:
        contacts = []
    return contacts    

def UpdateContact(contact):
    updatedContact = {}
    try:
        conn = GetConnection()
        cur = conn.cursor()
        cur.execute("UPDATE contacts SET name = ?, company = ?, phone = ?, email = ? WHERE id =?",  
                     (contact["name"],
                      contact["company"],
                      contact["phone"],
                      contact["email"],
                      contact["id"],))
        conn.commit()
        updatedContact = GetContactById(contact["id"])
    except:
        conn.rollback()
        updatedContact = {}
    finally:
        conn.close()
    return updatedContact    

def DeleteContactById(id):
    message = {}
    try:
        conn = GetConnection()
        conn.execute("DELETE from contacts WHERE id = ?",     
                      (id))
        conn.commit()
        message["status"] = "Contato excluido com sucesso"
    except:
        conn.rollback()
        message["status"] = "Não foi possivel excluir o contato"
    finally:
        conn.close()
    return message    