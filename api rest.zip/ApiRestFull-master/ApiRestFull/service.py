from asyncio.windows_events import NULL
from flask import Flask, request, jsonify

from db import GetAllContacts, GetContactById , GetContactByCompany, GetContactByEmail, GetContactByName, InsertContact, UpdateContact, DeleteContactById, CreateDbTable
app = Flask(__name__)

@app.route('/api/contacts', methods=['GET'])
def ActionGetAllContacts():
    return jsonify(GetAllContacts())

@app.route('/api/contacts/getbyid/<id>', methods=['GET'])
def ActionGetContactById(id):
    currentContact = GetContactById(id)
    if(len(currentContact) == 0):
        return jsonify({
            'status': '405',
             'msg': 'Contato não encontrado' })
    else:
        return jsonify({
                    'res': currentContact,
                    'status': '200',
                    'msg': 'Contato encontrado com sucesso'})

@app.route('/api/contacts/getbyname/<name>', methods=['GET'])
def ActionGetContactByName(name):
    currentContact = GetContactByName(name)
    if(len(currentContact) == 0):
        return jsonify({
            'status': '405',
             'msg': 'Contato não encontrado' })
    else:
        return jsonify({
                    'res': currentContact,
                    'status': '200',
                    'msg': 'Contato encontrado com sucesso'})

@app.route('/api/contacts/getbyemail/<email>', methods=['GET'])
def ActionGetContactByEmail(email):
    currentContact = GetContactByEmail(email)
    if(len(currentContact) == 0):
        return jsonify({
            'status': '405',
             'msg': 'Contato não encontrado' })
    else:
        return jsonify({
                    'res': currentContact,
                    'status': '200',
                    'msg': 'Contato encontrado com sucesso'})

@app.route('/api/contacts/getbycompany/<company>', methods=['GET'])
def ActionGetContactByCompany(company):
    currentContact = GetContactByCompany(company)
    if(len(currentContact) == 0):
        return jsonify({
            'status': '405',
             'msg': 'Contato não encontrado' })
    else:
        return jsonify({
                    'res': currentContact,
                    'status': '200',
                    'msg': 'Contato encontrado com sucesso'})   

@app.route('/api/contacts/add',  methods = ['POST'])
def ActionInsertContact():
    contact = request.get_json()
    contacts = GetAllContacts();
    for currentContact in contacts:
        if(currentContact["email"] == contact["email"] and currentContact["company"] == contact["company"]):
            return jsonify({
                "msg": "Este contato já se encontra cadastrado"
            })
        else:
            InsertContact(contact)
            return jsonify({
                'status': '200',
                'msg': 'Contato inserido com sucesso'})

@app.route('/api/contacts/update',  methods = ['PUT'])
def ActionUpdateContact():
    contact = request.get_json()
    currentContact = UpdateContact(contact)
    return jsonify({
               'res': currentContact,
               'status': '200',
               'msg': 'Contato atualizado com sucesso'})

@app.route('/api/contacts/delete/<id>',  methods = ['DELETE'])
def ActionDeleteContactById(id):
    DeleteContactById(id)
    return jsonify({
               'status': '200',
               'msg': 'Contato excluido com sucesso'})

@app.route('/api/contacts/create',  methods = ['GET'])
def ActionCreateDbTable():
    success = CreateDbTable()
    if(success):
        return jsonify({
            "msg": "Tabela de contatos criada com sucesso"
        })
    else:
        return jsonify({
            "msg": "Não foi possivel criar a tabela de contatos"
        })                       

if __name__ == "__main__":
    app.run()