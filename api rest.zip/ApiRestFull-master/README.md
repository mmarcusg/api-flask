# ApiRestFull
Trabalho da faculdade, api rest full em python, utilizando flask
